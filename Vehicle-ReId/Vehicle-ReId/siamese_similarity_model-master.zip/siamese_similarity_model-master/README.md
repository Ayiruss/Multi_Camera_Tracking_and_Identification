# siamese_similarity_model
A Siamese similarity model for image similarity

This project is currently unmaintained and is open for modification. Please feel free to fork it and use the project as pleased. 
